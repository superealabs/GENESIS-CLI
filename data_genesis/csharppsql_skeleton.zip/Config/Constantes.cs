﻿namespace [projectNameMaj].Config
{
    public class Constantes
    {
        public static int PAGINATION_LIMIT = 5;
    }
}
