package com.config;
public class Constantes {
    public static final int PAGINATION_LIMIT=5;
    public static final int SESSION_EXPIRE=30;
}
