package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="property")
public class Property  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@Column(name="name")
	private String name;

	@Column(name="description")
	private String description;

	@ManyToOne
	@JoinColumn(name="property_category_id")
	private PropertyCategory propertycategoryidPropertyCategory;

	@Column(name="capacity")
	private Integer capacity;

	@Column(name="percentage_down")
	private Double percentageDown;

	@Column(name="daily_price")
	private Double dailyPrice;

	@Column(name="opening_time")
	private java.time.LocalTime openingTime;

	@Column(name="closing_time")
	private java.time.LocalTime closingTime;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public String getName() {
	   return name;
	}

	public void setName(String name) {
	   this.name = name;
	}
	
	public String getDescription() {
	   return description;
	}

	public void setDescription(String description) {
	   this.description = description;
	}
	
	public PropertyCategory getPropertycategoryidPropertyCategory() {
	   return propertycategoryidPropertyCategory;
	}

	public void setPropertycategoryidPropertyCategory(PropertyCategory propertycategoryidPropertyCategory) {
	   this.propertycategoryidPropertyCategory = propertycategoryidPropertyCategory;
	}
	
	public Integer getCapacity() {
	   return capacity;
	}

	public void setCapacity(Integer capacity) {
	   this.capacity = capacity;
	}
	
	public Double getPercentageDown() {
	   return percentageDown;
	}

	public void setPercentageDown(Double percentageDown) {
	   this.percentageDown = percentageDown;
	}
	
	public Double getDailyPrice() {
	   return dailyPrice;
	}

	public void setDailyPrice(Double dailyPrice) {
	   this.dailyPrice = dailyPrice;
	}
	
	public java.time.LocalTime getOpeningTime() {
	   return openingTime;
	}

	public void setOpeningTime(java.time.LocalTime openingTime) {
	   this.openingTime = openingTime;
	}
	
	public java.time.LocalTime getClosingTime() {
	   return closingTime;
	}

	public void setClosingTime(java.time.LocalTime closingTime) {
	   this.closingTime = closingTime;
	}

}
