package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.Customer;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.CustomerService;
import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController  {
	private final CustomerService customerService;

	public CustomerController(CustomerService customerService) {
	   this.customerService = customerService;
	}

	@GetMapping
	public ResponseEntity<List<Customer>> getAllCustomers() {
	   List<Customer> customers = customerService.getAllCustomer();
	   return customers.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(customers);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable Long id) {
	   Customer customer = customerService.getCustomerById(id);
	   return ResponseEntity.ok(customer);
	}

	@PostMapping
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
	   Customer newCustomer = customerService.createCustomer(customer);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newCustomer);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable Long id, @RequestBody Customer customer) {
	   Customer updateCustomer = customerService.updateCustomer(id, customer);
	   return ResponseEntity.ok(updateCustomer);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteCustomerById(@PathVariable Long id) {
	   customerService.deleteCustomer(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
