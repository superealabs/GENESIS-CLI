package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.CashMovement;


public interface CashMovementRepository extends JpaRepository<CashMovement, Long> {
}
