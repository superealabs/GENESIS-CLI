package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.EquipmentCategory;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.EquipmentCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class EquipmentCategoryService  {
	private final EquipmentCategoryRepository equipmentCategoryRepository;

	@Autowired
	public EquipmentCategoryService(EquipmentCategoryRepository equipmentCategoryRepository) {
	   this.equipmentCategoryRepository = equipmentCategoryRepository;
	}

	public List<EquipmentCategory> getAllEquipmentCategory() {
	   return equipmentCategoryRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public EquipmentCategory getEquipmentCategoryById(Long id) {
	   Optional<EquipmentCategory> equipmentCategory = equipmentCategoryRepository.findById(id);
	   if (equipmentCategory.isPresent()) {
	     return equipmentCategory.get();
	   } else {
	     throw new RuntimeException("EquipmentCategory not found with id : " + id);
	   }
	}

	public EquipmentCategory createEquipmentCategory(EquipmentCategory equipmentCategory) {
	   return equipmentCategoryRepository.save(equipmentCategory);
	}

	public EquipmentCategory updateEquipmentCategory(Long id, EquipmentCategory equipmentCategory) {
	   Optional<EquipmentCategory> existingEquipmentCategory = equipmentCategoryRepository.findById(id);
			if (existingEquipmentCategory.isPresent()) {
			    equipmentCategory.setId(id);
	           return equipmentCategoryRepository.save(equipmentCategory);
	       } else {
	         throw new RuntimeException("EquipmentCategory not found with id : " + id);
	       }
	}

	public void deleteEquipmentCategory(Long id) {
	   equipmentCategoryRepository.deleteById(id);
	}

}
