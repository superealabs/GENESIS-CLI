package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.MeansPayment;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.MeansPaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class MeansPaymentService  {
	private final MeansPaymentRepository meansPaymentRepository;

	@Autowired
	public MeansPaymentService(MeansPaymentRepository meansPaymentRepository) {
	   this.meansPaymentRepository = meansPaymentRepository;
	}

	public List<MeansPayment> getAllMeansPayment() {
	   return meansPaymentRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public MeansPayment getMeansPaymentById(Long id) {
	   Optional<MeansPayment> meansPayment = meansPaymentRepository.findById(id);
	   if (meansPayment.isPresent()) {
	     return meansPayment.get();
	   } else {
	     throw new RuntimeException("MeansPayment not found with id : " + id);
	   }
	}

	public MeansPayment createMeansPayment(MeansPayment meansPayment) {
	   return meansPaymentRepository.save(meansPayment);
	}

	public MeansPayment updateMeansPayment(Long id, MeansPayment meansPayment) {
	   Optional<MeansPayment> existingMeansPayment = meansPaymentRepository.findById(id);
			if (existingMeansPayment.isPresent()) {
			    meansPayment.setId(id);
	           return meansPaymentRepository.save(meansPayment);
	       } else {
	         throw new RuntimeException("MeansPayment not found with id : " + id);
	       }
	}

	public void deleteMeansPayment(Long id) {
	   meansPaymentRepository.deleteById(id);
	}

}
