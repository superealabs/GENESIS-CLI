package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.DailyCashSummary;


public interface DailyCashSummaryRepository extends JpaRepository<DailyCashSummary, Long> {
}
