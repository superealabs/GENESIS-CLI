package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.CashMovementType;


public interface CashMovementTypeRepository extends JpaRepository<CashMovementType, Long> {
}
