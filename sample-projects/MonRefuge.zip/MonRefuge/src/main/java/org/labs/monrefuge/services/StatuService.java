package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.Statu;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.StatuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class StatuService  {
	private final StatuRepository statuRepository;

	@Autowired
	public StatuService(StatuRepository statuRepository) {
	   this.statuRepository = statuRepository;
	}

	public List<Statu> getAllStatu() {
	   return statuRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public Statu getStatuById(Long id) {
	   Optional<Statu> statu = statuRepository.findById(id);
	   if (statu.isPresent()) {
	     return statu.get();
	   } else {
	     throw new RuntimeException("Statu not found with id : " + id);
	   }
	}

	public Statu createStatu(Statu statu) {
	   return statuRepository.save(statu);
	}

	public Statu updateStatu(Long id, Statu statu) {
	   Optional<Statu> existingStatu = statuRepository.findById(id);
			if (existingStatu.isPresent()) {
			    statu.setId(id);
	           return statuRepository.save(statu);
	       } else {
	         throw new RuntimeException("Statu not found with id : " + id);
	       }
	}

	public void deleteStatu(Long id) {
	   statuRepository.deleteById(id);
	}

}
