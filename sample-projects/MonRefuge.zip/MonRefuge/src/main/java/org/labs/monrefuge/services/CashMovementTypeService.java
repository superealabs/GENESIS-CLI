package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.CashMovementType;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.CashMovementTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class CashMovementTypeService  {
	private final CashMovementTypeRepository cashMovementTypeRepository;

	@Autowired
	public CashMovementTypeService(CashMovementTypeRepository cashMovementTypeRepository) {
	   this.cashMovementTypeRepository = cashMovementTypeRepository;
	}

	public List<CashMovementType> getAllCashMovementType() {
	   return cashMovementTypeRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public CashMovementType getCashMovementTypeById(Long id) {
	   Optional<CashMovementType> cashMovementType = cashMovementTypeRepository.findById(id);
	   if (cashMovementType.isPresent()) {
	     return cashMovementType.get();
	   } else {
	     throw new RuntimeException("CashMovementType not found with id : " + id);
	   }
	}

	public CashMovementType createCashMovementType(CashMovementType cashMovementType) {
	   return cashMovementTypeRepository.save(cashMovementType);
	}

	public CashMovementType updateCashMovementType(Long id, CashMovementType cashMovementType) {
	   Optional<CashMovementType> existingCashMovementType = cashMovementTypeRepository.findById(id);
			if (existingCashMovementType.isPresent()) {
			    cashMovementType.setId(id);
	           return cashMovementTypeRepository.save(cashMovementType);
	       } else {
	         throw new RuntimeException("CashMovementType not found with id : " + id);
	       }
	}

	public void deleteCashMovementType(Long id) {
	   cashMovementTypeRepository.deleteById(id);
	}

}
