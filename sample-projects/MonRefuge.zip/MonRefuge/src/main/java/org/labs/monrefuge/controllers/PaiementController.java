package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.Paiement;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.PaiementService;
import java.util.List;

@RestController
@RequestMapping("/paiements")
public class PaiementController  {
	private final PaiementService paiementService;

	public PaiementController(PaiementService paiementService) {
	   this.paiementService = paiementService;
	}

	@GetMapping
	public ResponseEntity<List<Paiement>> getAllPaiements() {
	   List<Paiement> paiements = paiementService.getAllPaiement();
	   return paiements.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(paiements);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Paiement> getPaiementById(@PathVariable Long id) {
	   Paiement paiement = paiementService.getPaiementById(id);
	   return ResponseEntity.ok(paiement);
	}

	@PostMapping
	public ResponseEntity<Paiement> createPaiement(@RequestBody Paiement paiement) {
	   Paiement newPaiement = paiementService.createPaiement(paiement);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newPaiement);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Paiement> updatePaiement(@PathVariable Long id, @RequestBody Paiement paiement) {
	   Paiement updatePaiement = paiementService.updatePaiement(id, paiement);
	   return ResponseEntity.ok(updatePaiement);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletePaiementById(@PathVariable Long id) {
	   paiementService.deletePaiement(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
