package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="equipment_motion")
public class EquipmentMotion  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@ManyToOne
	@JoinColumn(name="equipment_id")
	private Equipment equipmentidEquipment;

	@Column(name="motion_date")
	private java.time.LocalDateTime motionDate;

	@Column(name="quantity")
	private Integer quantity;

	@Column(name="price_unit")
	private Double priceUnit;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public Equipment getEquipmentidEquipment() {
	   return equipmentidEquipment;
	}

	public void setEquipmentidEquipment(Equipment equipmentidEquipment) {
	   this.equipmentidEquipment = equipmentidEquipment;
	}
	
	public java.time.LocalDateTime getMotionDate() {
	   return motionDate;
	}

	public void setMotionDate(java.time.LocalDateTime motionDate) {
	   this.motionDate = motionDate;
	}
	
	public Integer getQuantity() {
	   return quantity;
	}

	public void setQuantity(Integer quantity) {
	   this.quantity = quantity;
	}
	
	public Double getPriceUnit() {
	   return priceUnit;
	}

	public void setPriceUnit(Double priceUnit) {
	   this.priceUnit = priceUnit;
	}

}
