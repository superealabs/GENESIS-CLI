package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.CashMovementsTypeCategorie;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.CashMovementsTypeCategorieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class CashMovementsTypeCategorieService  {
	private final CashMovementsTypeCategorieRepository cashMovementsTypeCategorieRepository;

	@Autowired
	public CashMovementsTypeCategorieService(CashMovementsTypeCategorieRepository cashMovementsTypeCategorieRepository) {
	   this.cashMovementsTypeCategorieRepository = cashMovementsTypeCategorieRepository;
	}

	public List<CashMovementsTypeCategorie> getAllCashMovementsTypeCategorie() {
	   return cashMovementsTypeCategorieRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public CashMovementsTypeCategorie getCashMovementsTypeCategorieById(Long id) {
	   Optional<CashMovementsTypeCategorie> cashMovementsTypeCategorie = cashMovementsTypeCategorieRepository.findById(id);
	   if (cashMovementsTypeCategorie.isPresent()) {
	     return cashMovementsTypeCategorie.get();
	   } else {
	     throw new RuntimeException("CashMovementsTypeCategorie not found with id : " + id);
	   }
	}

	public CashMovementsTypeCategorie createCashMovementsTypeCategorie(CashMovementsTypeCategorie cashMovementsTypeCategorie) {
	   return cashMovementsTypeCategorieRepository.save(cashMovementsTypeCategorie);
	}

	public CashMovementsTypeCategorie updateCashMovementsTypeCategorie(Long id, CashMovementsTypeCategorie cashMovementsTypeCategorie) {
	   Optional<CashMovementsTypeCategorie> existingCashMovementsTypeCategorie = cashMovementsTypeCategorieRepository.findById(id);
			if (existingCashMovementsTypeCategorie.isPresent()) {
			    cashMovementsTypeCategorie.setId(id);
	           return cashMovementsTypeCategorieRepository.save(cashMovementsTypeCategorie);
	       } else {
	         throw new RuntimeException("CashMovementsTypeCategorie not found with id : " + id);
	       }
	}

	public void deleteCashMovementsTypeCategorie(Long id) {
	   cashMovementsTypeCategorieRepository.deleteById(id);
	}

}
