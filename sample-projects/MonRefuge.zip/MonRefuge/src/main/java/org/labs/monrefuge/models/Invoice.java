package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="invoices")
public class Invoice  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@Column(name="reference_facture")
	private String referenceFacture;

	@ManyToOne
	@JoinColumn(name="status_motion_id")
	private StatusMotion statusmotionidStatusMotion;

	@Column(name="total_price")
	private Double totalPrice;

	@Column(name="pay_amount")
	private Double payAmount;

	@Column(name="invoice_date")
	private java.time.LocalDateTime invoiceDate;

	@Column(name="payment_deadline_date")
	private java.time.LocalDateTime paymentDeadlineDate;

	@Column(name="discount_payment_deadline_date")
	private java.time.LocalDateTime discountPaymentDeadlineDate;

	@Column(name="percentage_down")
	private Double percentageDown;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public String getReferenceFacture() {
	   return referenceFacture;
	}

	public void setReferenceFacture(String referenceFacture) {
	   this.referenceFacture = referenceFacture;
	}
	
	public StatusMotion getStatusmotionidStatusMotion() {
	   return statusmotionidStatusMotion;
	}

	public void setStatusmotionidStatusMotion(StatusMotion statusmotionidStatusMotion) {
	   this.statusmotionidStatusMotion = statusmotionidStatusMotion;
	}
	
	public Double getTotalPrice() {
	   return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
	   this.totalPrice = totalPrice;
	}
	
	public Double getPayAmount() {
	   return payAmount;
	}

	public void setPayAmount(Double payAmount) {
	   this.payAmount = payAmount;
	}
	
	public java.time.LocalDateTime getInvoiceDate() {
	   return invoiceDate;
	}

	public void setInvoiceDate(java.time.LocalDateTime invoiceDate) {
	   this.invoiceDate = invoiceDate;
	}
	
	public java.time.LocalDateTime getPaymentDeadlineDate() {
	   return paymentDeadlineDate;
	}

	public void setPaymentDeadlineDate(java.time.LocalDateTime paymentDeadlineDate) {
	   this.paymentDeadlineDate = paymentDeadlineDate;
	}
	
	public java.time.LocalDateTime getDiscountPaymentDeadlineDate() {
	   return discountPaymentDeadlineDate;
	}

	public void setDiscountPaymentDeadlineDate(java.time.LocalDateTime discountPaymentDeadlineDate) {
	   this.discountPaymentDeadlineDate = discountPaymentDeadlineDate;
	}
	
	public Double getPercentageDown() {
	   return percentageDown;
	}

	public void setPercentageDown(Double percentageDown) {
	   this.percentageDown = percentageDown;
	}

}
