package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.DailyCashSummary;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.DailyCashSummaryService;
import java.util.List;

@RestController
@RequestMapping("/dailycashsummarys")
public class DailyCashSummaryController  {
	private final DailyCashSummaryService dailycashsummaryService;

	public DailyCashSummaryController(DailyCashSummaryService dailycashsummaryService) {
	   this.dailycashsummaryService = dailycashsummaryService;
	}

	@GetMapping
	public ResponseEntity<List<DailyCashSummary>> getAllDailyCashSummarys() {
	   List<DailyCashSummary> dailycashsummarys = dailycashsummaryService.getAllDailyCashSummary();
	   return dailycashsummarys.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(dailycashsummarys);
	}

	@GetMapping("/{id}")
	public ResponseEntity<DailyCashSummary> getDailyCashSummaryById(@PathVariable Long id) {
	   DailyCashSummary dailycashsummary = dailycashsummaryService.getDailyCashSummaryById(id);
	   return ResponseEntity.ok(dailycashsummary);
	}

	@PostMapping
	public ResponseEntity<DailyCashSummary> createDailyCashSummary(@RequestBody DailyCashSummary dailycashsummary) {
	   DailyCashSummary newDailyCashSummary = dailycashsummaryService.createDailyCashSummary(dailycashsummary);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newDailyCashSummary);
	}

	@PutMapping("/{id}")
	public ResponseEntity<DailyCashSummary> updateDailyCashSummary(@PathVariable Long id, @RequestBody DailyCashSummary dailycashsummary) {
	   DailyCashSummary updateDailyCashSummary = dailycashsummaryService.updateDailyCashSummary(id, dailycashsummary);
	   return ResponseEntity.ok(updateDailyCashSummary);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteDailyCashSummaryById(@PathVariable Long id) {
	   dailycashsummaryService.deleteDailyCashSummary(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
