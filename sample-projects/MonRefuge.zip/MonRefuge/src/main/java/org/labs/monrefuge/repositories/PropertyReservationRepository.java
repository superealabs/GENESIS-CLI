package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.PropertyReservation;


public interface PropertyReservationRepository extends JpaRepository<PropertyReservation, Long> {
}
