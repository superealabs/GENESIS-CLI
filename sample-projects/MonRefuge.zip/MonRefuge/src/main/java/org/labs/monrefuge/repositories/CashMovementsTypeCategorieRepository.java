package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.CashMovementsTypeCategorie;


public interface CashMovementsTypeCategorieRepository extends JpaRepository<CashMovementsTypeCategorie, Long> {
}
