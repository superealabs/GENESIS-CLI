package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.Property;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.PropertyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyService  {
	private final PropertyRepository propertyRepository;

	@Autowired
	public PropertyService(PropertyRepository propertyRepository) {
	   this.propertyRepository = propertyRepository;
	}

	public List<Property> getAllProperty() {
	   return propertyRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public Property getPropertyById(Long id) {
	   Optional<Property> property = propertyRepository.findById(id);
	   if (property.isPresent()) {
	     return property.get();
	   } else {
	     throw new RuntimeException("Property not found with id : " + id);
	   }
	}

	public Property createProperty(Property property) {
	   return propertyRepository.save(property);
	}

	public Property updateProperty(Long id, Property property) {
	   Optional<Property> existingProperty = propertyRepository.findById(id);
			if (existingProperty.isPresent()) {
			    property.setId(id);
	           return propertyRepository.save(property);
	       } else {
	         throw new RuntimeException("Property not found with id : " + id);
	       }
	}

	public void deleteProperty(Long id) {
	   propertyRepository.deleteById(id);
	}

}
