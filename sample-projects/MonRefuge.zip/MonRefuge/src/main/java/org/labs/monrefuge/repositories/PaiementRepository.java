package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.Paiement;


public interface PaiementRepository extends JpaRepository<Paiement, Long> {
}
