package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.CashMovementsCategorie;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.CashMovementsCategorieService;
import java.util.List;

@RestController
@RequestMapping("/cashmovementscategories")
public class CashMovementsCategorieController  {
	private final CashMovementsCategorieService cashmovementscategorieService;

	public CashMovementsCategorieController(CashMovementsCategorieService cashmovementscategorieService) {
	   this.cashmovementscategorieService = cashmovementscategorieService;
	}

	@GetMapping
	public ResponseEntity<List<CashMovementsCategorie>> getAllCashMovementsCategories() {
	   List<CashMovementsCategorie> cashmovementscategories = cashmovementscategorieService.getAllCashMovementsCategorie();
	   return cashmovementscategories.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(cashmovementscategories);
	}

	@GetMapping("/{id}")
	public ResponseEntity<CashMovementsCategorie> getCashMovementsCategorieById(@PathVariable Long id) {
	   CashMovementsCategorie cashmovementscategorie = cashmovementscategorieService.getCashMovementsCategorieById(id);
	   return ResponseEntity.ok(cashmovementscategorie);
	}

	@PostMapping
	public ResponseEntity<CashMovementsCategorie> createCashMovementsCategorie(@RequestBody CashMovementsCategorie cashmovementscategorie) {
	   CashMovementsCategorie newCashMovementsCategorie = cashmovementscategorieService.createCashMovementsCategorie(cashmovementscategorie);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newCashMovementsCategorie);
	}

	@PutMapping("/{id}")
	public ResponseEntity<CashMovementsCategorie> updateCashMovementsCategorie(@PathVariable Long id, @RequestBody CashMovementsCategorie cashmovementscategorie) {
	   CashMovementsCategorie updateCashMovementsCategorie = cashmovementscategorieService.updateCashMovementsCategorie(id, cashmovementscategorie);
	   return ResponseEntity.ok(updateCashMovementsCategorie);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteCashMovementsCategorieById(@PathVariable Long id) {
	   cashmovementscategorieService.deleteCashMovementsCategorie(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
