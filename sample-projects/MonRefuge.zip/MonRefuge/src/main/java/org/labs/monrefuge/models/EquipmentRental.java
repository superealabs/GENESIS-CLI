package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="equipment_rental")
public class EquipmentRental  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@ManyToOne
	@JoinColumn(name="customer_id")
	private Customer customeridCustomer;

	@ManyToOne
	@JoinColumn(name="equipment_id")
	private Equipment equipmentidEquipment;

	@Column(name="equipment_number")
	private Integer equipmentNumber;

	@Column(name="start_date")
	private java.time.LocalDateTime startDate;

	@Column(name="end_date")
	private java.time.LocalDateTime endDate;

	@Column(name="rental_date_time")
	private java.time.LocalDateTime rentalDateTime;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public Customer getCustomeridCustomer() {
	   return customeridCustomer;
	}

	public void setCustomeridCustomer(Customer customeridCustomer) {
	   this.customeridCustomer = customeridCustomer;
	}
	
	public Equipment getEquipmentidEquipment() {
	   return equipmentidEquipment;
	}

	public void setEquipmentidEquipment(Equipment equipmentidEquipment) {
	   this.equipmentidEquipment = equipmentidEquipment;
	}
	
	public Integer getEquipmentNumber() {
	   return equipmentNumber;
	}

	public void setEquipmentNumber(Integer equipmentNumber) {
	   this.equipmentNumber = equipmentNumber;
	}
	
	public java.time.LocalDateTime getStartDate() {
	   return startDate;
	}

	public void setStartDate(java.time.LocalDateTime startDate) {
	   this.startDate = startDate;
	}
	
	public java.time.LocalDateTime getEndDate() {
	   return endDate;
	}

	public void setEndDate(java.time.LocalDateTime endDate) {
	   this.endDate = endDate;
	}
	
	public java.time.LocalDateTime getRentalDateTime() {
	   return rentalDateTime;
	}

	public void setRentalDateTime(java.time.LocalDateTime rentalDateTime) {
	   this.rentalDateTime = rentalDateTime;
	}

}
