package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.CashMovement;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.CashMovementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class CashMovementService  {
	private final CashMovementRepository cashMovementRepository;

	@Autowired
	public CashMovementService(CashMovementRepository cashMovementRepository) {
	   this.cashMovementRepository = cashMovementRepository;
	}

	public List<CashMovement> getAllCashMovement() {
	   return cashMovementRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public CashMovement getCashMovementById(Long id) {
	   Optional<CashMovement> cashMovement = cashMovementRepository.findById(id);
	   if (cashMovement.isPresent()) {
	     return cashMovement.get();
	   } else {
	     throw new RuntimeException("CashMovement not found with id : " + id);
	   }
	}

	public CashMovement createCashMovement(CashMovement cashMovement) {
	   return cashMovementRepository.save(cashMovement);
	}

	public CashMovement updateCashMovement(Long id, CashMovement cashMovement) {
	   Optional<CashMovement> existingCashMovement = cashMovementRepository.findById(id);
			if (existingCashMovement.isPresent()) {
			    cashMovement.setId(id);
	           return cashMovementRepository.save(cashMovement);
	       } else {
	         throw new RuntimeException("CashMovement not found with id : " + id);
	       }
	}

	public void deleteCashMovement(Long id) {
	   cashMovementRepository.deleteById(id);
	}

}
