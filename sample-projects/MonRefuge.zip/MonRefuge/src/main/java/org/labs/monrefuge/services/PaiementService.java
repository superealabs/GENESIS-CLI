package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.Paiement;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.PaiementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class PaiementService  {
	private final PaiementRepository paiementRepository;

	@Autowired
	public PaiementService(PaiementRepository paiementRepository) {
	   this.paiementRepository = paiementRepository;
	}

	public List<Paiement> getAllPaiement() {
	   return paiementRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public Paiement getPaiementById(Long id) {
	   Optional<Paiement> paiement = paiementRepository.findById(id);
	   if (paiement.isPresent()) {
	     return paiement.get();
	   } else {
	     throw new RuntimeException("Paiement not found with id : " + id);
	   }
	}

	public Paiement createPaiement(Paiement paiement) {
	   return paiementRepository.save(paiement);
	}

	public Paiement updatePaiement(Long id, Paiement paiement) {
	   Optional<Paiement> existingPaiement = paiementRepository.findById(id);
			if (existingPaiement.isPresent()) {
			    paiement.setId(id);
	           return paiementRepository.save(paiement);
	       } else {
	         throw new RuntimeException("Paiement not found with id : " + id);
	       }
	}

	public void deletePaiement(Long id) {
	   paiementRepository.deleteById(id);
	}

}
