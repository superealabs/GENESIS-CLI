package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="daily_cash_summary")
public class DailyCashSummary  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@Column(name="date")
	private java.time.LocalDate date;

	@Column(name="total_app_amount")
	private Double totalAppAmount;

	@Column(name="total_physical")
	private Double totalPhysical;

	@Column(name="discrepancy")
	private Double discrepancy;

	@Column(name="observations")
	private String observations;

	@Column(name="created_at")
	private java.time.LocalDateTime createdAt;

	@ManyToOne
	@JoinColumn(name="created_by")
	private User createdbyUser;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public java.time.LocalDate getDate() {
	   return date;
	}

	public void setDate(java.time.LocalDate date) {
	   this.date = date;
	}
	
	public Double getTotalAppAmount() {
	   return totalAppAmount;
	}

	public void setTotalAppAmount(Double totalAppAmount) {
	   this.totalAppAmount = totalAppAmount;
	}
	
	public Double getTotalPhysical() {
	   return totalPhysical;
	}

	public void setTotalPhysical(Double totalPhysical) {
	   this.totalPhysical = totalPhysical;
	}
	
	public Double getDiscrepancy() {
	   return discrepancy;
	}

	public void setDiscrepancy(Double discrepancy) {
	   this.discrepancy = discrepancy;
	}
	
	public String getObservations() {
	   return observations;
	}

	public void setObservations(String observations) {
	   this.observations = observations;
	}
	
	public java.time.LocalDateTime getCreatedAt() {
	   return createdAt;
	}

	public void setCreatedAt(java.time.LocalDateTime createdAt) {
	   this.createdAt = createdAt;
	}
	
	public User getCreatedbyUser() {
	   return createdbyUser;
	}

	public void setCreatedbyUser(User createdbyUser) {
	   this.createdbyUser = createdbyUser;
	}

}
