package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="status_motion")
public class StatusMotion  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@ManyToOne
	@JoinColumn(name="user_id")
	private User useridUser;

	@ManyToOne
	@JoinColumn(name="property_reservation_id")
	private PropertyReservation propertyreservationidPropertyReservation;

	@ManyToOne
	@JoinColumn(name="equipment_rental_id")
	private EquipmentRental equipmentrentalidEquipmentRental;

	@ManyToOne
	@JoinColumn(name="status_id")
	private Statu statusidStatus;

	@Column(name="date_motion")
	private java.time.LocalDateTime dateMotion;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public User getUseridUser() {
	   return useridUser;
	}

	public void setUseridUser(User useridUser) {
	   this.useridUser = useridUser;
	}
	
	public PropertyReservation getPropertyreservationidPropertyReservation() {
	   return propertyreservationidPropertyReservation;
	}

	public void setPropertyreservationidPropertyReservation(PropertyReservation propertyreservationidPropertyReservation) {
	   this.propertyreservationidPropertyReservation = propertyreservationidPropertyReservation;
	}
	
	public EquipmentRental getEquipmentrentalidEquipmentRental() {
	   return equipmentrentalidEquipmentRental;
	}

	public void setEquipmentrentalidEquipmentRental(EquipmentRental equipmentrentalidEquipmentRental) {
	   this.equipmentrentalidEquipmentRental = equipmentrentalidEquipmentRental;
	}
	
	public Statu getStatusidStatus() {
	   return statusidStatus;
	}

	public void setStatusidStatus(Statu statusidStatus) {
	   this.statusidStatus = statusidStatus;
	}
	
	public java.time.LocalDateTime getDateMotion() {
	   return dateMotion;
	}

	public void setDateMotion(java.time.LocalDateTime dateMotion) {
	   this.dateMotion = dateMotion;
	}

}
