package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.User;


public interface UserRepository extends JpaRepository<User, Long> {
}
