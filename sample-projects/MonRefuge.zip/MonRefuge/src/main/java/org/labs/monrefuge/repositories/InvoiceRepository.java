package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.Invoice;


public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
}
