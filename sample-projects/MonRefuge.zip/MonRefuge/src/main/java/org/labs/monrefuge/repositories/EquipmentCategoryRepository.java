package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.EquipmentCategory;


public interface EquipmentCategoryRepository extends JpaRepository<EquipmentCategory, Long> {
}
