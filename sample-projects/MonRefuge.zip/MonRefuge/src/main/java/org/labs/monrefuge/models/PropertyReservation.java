package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="property_reservation")
public class PropertyReservation  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@ManyToOne
	@JoinColumn(name="customer_id")
	private Customer customeridCustomer;

	@ManyToOne
	@JoinColumn(name="property_id")
	private Property propertyidProperty;

	@Column(name="person_number")
	private Integer personNumber;

	@Column(name="start_date")
	private java.time.LocalDateTime startDate;

	@Column(name="end_date")
	private java.time.LocalDateTime endDate;

	@Column(name="reservation_date_time")
	private java.time.LocalDateTime reservationDateTime;

	@Column(name="date_range")
	private String dateRange;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public Customer getCustomeridCustomer() {
	   return customeridCustomer;
	}

	public void setCustomeridCustomer(Customer customeridCustomer) {
	   this.customeridCustomer = customeridCustomer;
	}
	
	public Property getPropertyidProperty() {
	   return propertyidProperty;
	}

	public void setPropertyidProperty(Property propertyidProperty) {
	   this.propertyidProperty = propertyidProperty;
	}
	
	public Integer getPersonNumber() {
	   return personNumber;
	}

	public void setPersonNumber(Integer personNumber) {
	   this.personNumber = personNumber;
	}
	
	public java.time.LocalDateTime getStartDate() {
	   return startDate;
	}

	public void setStartDate(java.time.LocalDateTime startDate) {
	   this.startDate = startDate;
	}
	
	public java.time.LocalDateTime getEndDate() {
	   return endDate;
	}

	public void setEndDate(java.time.LocalDateTime endDate) {
	   this.endDate = endDate;
	}
	
	public java.time.LocalDateTime getReservationDateTime() {
	   return reservationDateTime;
	}

	public void setReservationDateTime(java.time.LocalDateTime reservationDateTime) {
	   this.reservationDateTime = reservationDateTime;
	}
	
	public String getDateRange() {
	   return dateRange;
	}

	public void setDateRange(String dateRange) {
	   this.dateRange = dateRange;
	}

}
