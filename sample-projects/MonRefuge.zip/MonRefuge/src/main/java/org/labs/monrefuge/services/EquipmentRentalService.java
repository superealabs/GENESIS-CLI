package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.EquipmentRental;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.EquipmentRentalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class EquipmentRentalService  {
	private final EquipmentRentalRepository equipmentRentalRepository;

	@Autowired
	public EquipmentRentalService(EquipmentRentalRepository equipmentRentalRepository) {
	   this.equipmentRentalRepository = equipmentRentalRepository;
	}

	public List<EquipmentRental> getAllEquipmentRental() {
	   return equipmentRentalRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public EquipmentRental getEquipmentRentalById(Long id) {
	   Optional<EquipmentRental> equipmentRental = equipmentRentalRepository.findById(id);
	   if (equipmentRental.isPresent()) {
	     return equipmentRental.get();
	   } else {
	     throw new RuntimeException("EquipmentRental not found with id : " + id);
	   }
	}

	public EquipmentRental createEquipmentRental(EquipmentRental equipmentRental) {
	   return equipmentRentalRepository.save(equipmentRental);
	}

	public EquipmentRental updateEquipmentRental(Long id, EquipmentRental equipmentRental) {
	   Optional<EquipmentRental> existingEquipmentRental = equipmentRentalRepository.findById(id);
			if (existingEquipmentRental.isPresent()) {
			    equipmentRental.setId(id);
	           return equipmentRentalRepository.save(equipmentRental);
	       } else {
	         throw new RuntimeException("EquipmentRental not found with id : " + id);
	       }
	}

	public void deleteEquipmentRental(Long id) {
	   equipmentRentalRepository.deleteById(id);
	}

}
