package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="cash_movements_type_categories")
public class CashMovementsTypeCategorie  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@ManyToOne
	@JoinColumn(name="type_id")
	private CashMovementType typeidCashMovementTypes;

	@ManyToOne
	@JoinColumn(name="category_id")
	private CashMovementsCategorie categoryidCashMovementsCategories;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public CashMovementType getTypeidCashMovementTypes() {
	   return typeidCashMovementTypes;
	}

	public void setTypeidCashMovementTypes(CashMovementType typeidCashMovementTypes) {
	   this.typeidCashMovementTypes = typeidCashMovementTypes;
	}
	
	public CashMovementsCategorie getCategoryidCashMovementsCategories() {
	   return categoryidCashMovementsCategories;
	}

	public void setCategoryidCashMovementsCategories(CashMovementsCategorie categoryidCashMovementsCategories) {
	   this.categoryidCashMovementsCategories = categoryidCashMovementsCategories;
	}

}
