package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.ReservationParameter;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.ReservationParameterService;
import java.util.List;

@RestController
@RequestMapping("/reservationparameters")
public class ReservationParameterController  {
	private final ReservationParameterService reservationparameterService;

	public ReservationParameterController(ReservationParameterService reservationparameterService) {
	   this.reservationparameterService = reservationparameterService;
	}

	@GetMapping
	public ResponseEntity<List<ReservationParameter>> getAllReservationParameters() {
	   List<ReservationParameter> reservationparameters = reservationparameterService.getAllReservationParameter();
	   return reservationparameters.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(reservationparameters);
	}

	@GetMapping("/{id}")
	public ResponseEntity<ReservationParameter> getReservationParameterById(@PathVariable Long id) {
	   ReservationParameter reservationparameter = reservationparameterService.getReservationParameterById(id);
	   return ResponseEntity.ok(reservationparameter);
	}

	@PostMapping
	public ResponseEntity<ReservationParameter> createReservationParameter(@RequestBody ReservationParameter reservationparameter) {
	   ReservationParameter newReservationParameter = reservationparameterService.createReservationParameter(reservationparameter);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newReservationParameter);
	}

	@PutMapping("/{id}")
	public ResponseEntity<ReservationParameter> updateReservationParameter(@PathVariable Long id, @RequestBody ReservationParameter reservationparameter) {
	   ReservationParameter updateReservationParameter = reservationparameterService.updateReservationParameter(id, reservationparameter);
	   return ResponseEntity.ok(updateReservationParameter);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteReservationParameterById(@PathVariable Long id) {
	   reservationparameterService.deleteReservationParameter(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
