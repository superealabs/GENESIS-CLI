package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.Equipment;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.EquipmentService;
import java.util.List;

@RestController
@RequestMapping("/equipments")
public class EquipmentController  {
	private final EquipmentService equipmentService;

	public EquipmentController(EquipmentService equipmentService) {
	   this.equipmentService = equipmentService;
	}

	@GetMapping
	public ResponseEntity<List<Equipment>> getAllEquipments() {
	   List<Equipment> equipments = equipmentService.getAllEquipment();
	   return equipments.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(equipments);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Equipment> getEquipmentById(@PathVariable Long id) {
	   Equipment equipment = equipmentService.getEquipmentById(id);
	   return ResponseEntity.ok(equipment);
	}

	@PostMapping
	public ResponseEntity<Equipment> createEquipment(@RequestBody Equipment equipment) {
	   Equipment newEquipment = equipmentService.createEquipment(equipment);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newEquipment);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Equipment> updateEquipment(@PathVariable Long id, @RequestBody Equipment equipment) {
	   Equipment updateEquipment = equipmentService.updateEquipment(id, equipment);
	   return ResponseEntity.ok(updateEquipment);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteEquipmentById(@PathVariable Long id) {
	   equipmentService.deleteEquipment(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
