package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.PropertyReservation;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.PropertyReservationService;
import java.util.List;

@RestController
@RequestMapping("/propertyreservations")
public class PropertyReservationController  {
	private final PropertyReservationService propertyreservationService;

	public PropertyReservationController(PropertyReservationService propertyreservationService) {
	   this.propertyreservationService = propertyreservationService;
	}

	@GetMapping
	public ResponseEntity<List<PropertyReservation>> getAllPropertyReservations() {
	   List<PropertyReservation> propertyreservations = propertyreservationService.getAllPropertyReservation();
	   return propertyreservations.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(propertyreservations);
	}

	@GetMapping("/{id}")
	public ResponseEntity<PropertyReservation> getPropertyReservationById(@PathVariable Long id) {
	   PropertyReservation propertyreservation = propertyreservationService.getPropertyReservationById(id);
	   return ResponseEntity.ok(propertyreservation);
	}

	@PostMapping
	public ResponseEntity<PropertyReservation> createPropertyReservation(@RequestBody PropertyReservation propertyreservation) {
	   PropertyReservation newPropertyReservation = propertyreservationService.createPropertyReservation(propertyreservation);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newPropertyReservation);
	}

	@PutMapping("/{id}")
	public ResponseEntity<PropertyReservation> updatePropertyReservation(@PathVariable Long id, @RequestBody PropertyReservation propertyreservation) {
	   PropertyReservation updatePropertyReservation = propertyreservationService.updatePropertyReservation(id, propertyreservation);
	   return ResponseEntity.ok(updatePropertyReservation);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletePropertyReservationById(@PathVariable Long id) {
	   propertyreservationService.deletePropertyReservation(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
