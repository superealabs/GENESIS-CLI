package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.PropertyCategory;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.PropertyCategoryService;
import java.util.List;

@RestController
@RequestMapping("/propertycategorys")
public class PropertyCategoryController  {
	private final PropertyCategoryService propertycategoryService;

	public PropertyCategoryController(PropertyCategoryService propertycategoryService) {
	   this.propertycategoryService = propertycategoryService;
	}

	@GetMapping
	public ResponseEntity<List<PropertyCategory>> getAllPropertyCategorys() {
	   List<PropertyCategory> propertycategorys = propertycategoryService.getAllPropertyCategory();
	   return propertycategorys.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(propertycategorys);
	}

	@GetMapping("/{id}")
	public ResponseEntity<PropertyCategory> getPropertyCategoryById(@PathVariable Long id) {
	   PropertyCategory propertycategory = propertycategoryService.getPropertyCategoryById(id);
	   return ResponseEntity.ok(propertycategory);
	}

	@PostMapping
	public ResponseEntity<PropertyCategory> createPropertyCategory(@RequestBody PropertyCategory propertycategory) {
	   PropertyCategory newPropertyCategory = propertycategoryService.createPropertyCategory(propertycategory);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newPropertyCategory);
	}

	@PutMapping("/{id}")
	public ResponseEntity<PropertyCategory> updatePropertyCategory(@PathVariable Long id, @RequestBody PropertyCategory propertycategory) {
	   PropertyCategory updatePropertyCategory = propertycategoryService.updatePropertyCategory(id, propertycategory);
	   return ResponseEntity.ok(updatePropertyCategory);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletePropertyCategoryById(@PathVariable Long id) {
	   propertycategoryService.deletePropertyCategory(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
