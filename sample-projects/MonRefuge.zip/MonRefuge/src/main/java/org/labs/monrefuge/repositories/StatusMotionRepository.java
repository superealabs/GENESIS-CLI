package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.StatusMotion;


public interface StatusMotionRepository extends JpaRepository<StatusMotion, Long> {
}
