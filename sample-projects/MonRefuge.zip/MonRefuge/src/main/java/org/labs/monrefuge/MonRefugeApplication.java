package org.labs.monrefuge;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info; 
import org.springframework.context.annotation.Bean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class MonRefugeApplication {
    public static void main(String[] args) {
        SpringApplication.run(MonRefugeApplication.class, args);
    }

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                    .info(new Info().title("MonRefuge")
                    .description("Mon Refuge - Backend")
                    .version("0.0.1-SNAPSHOT"));
    }
}
