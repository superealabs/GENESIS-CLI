package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="customer")
public class Customer  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@Column(name="name")
	private String name;

	@Column(name="first_name")
	private String firstName;

	@Column(name="phone_number")
	private String phoneNumber;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public String getName() {
	   return name;
	}

	public void setName(String name) {
	   this.name = name;
	}
	
	public String getFirstName() {
	   return firstName;
	}

	public void setFirstName(String firstName) {
	   this.firstName = firstName;
	}
	
	public String getPhoneNumber() {
	   return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
	   this.phoneNumber = phoneNumber;
	}

}
