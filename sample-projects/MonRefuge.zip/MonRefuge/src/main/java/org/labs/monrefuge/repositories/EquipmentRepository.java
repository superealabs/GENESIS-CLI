package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.Equipment;


public interface EquipmentRepository extends JpaRepository<Equipment, Long> {
}
