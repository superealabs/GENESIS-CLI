package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.StatusMotion;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.StatusMotionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class StatusMotionService  {
	private final StatusMotionRepository statusMotionRepository;

	@Autowired
	public StatusMotionService(StatusMotionRepository statusMotionRepository) {
	   this.statusMotionRepository = statusMotionRepository;
	}

	public List<StatusMotion> getAllStatusMotion() {
	   return statusMotionRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public StatusMotion getStatusMotionById(Long id) {
	   Optional<StatusMotion> statusMotion = statusMotionRepository.findById(id);
	   if (statusMotion.isPresent()) {
	     return statusMotion.get();
	   } else {
	     throw new RuntimeException("StatusMotion not found with id : " + id);
	   }
	}

	public StatusMotion createStatusMotion(StatusMotion statusMotion) {
	   return statusMotionRepository.save(statusMotion);
	}

	public StatusMotion updateStatusMotion(Long id, StatusMotion statusMotion) {
	   Optional<StatusMotion> existingStatusMotion = statusMotionRepository.findById(id);
			if (existingStatusMotion.isPresent()) {
			    statusMotion.setId(id);
	           return statusMotionRepository.save(statusMotion);
	       } else {
	         throw new RuntimeException("StatusMotion not found with id : " + id);
	       }
	}

	public void deleteStatusMotion(Long id) {
	   statusMotionRepository.deleteById(id);
	}

}
