package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.CashMovementType;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.CashMovementTypeService;
import java.util.List;

@RestController
@RequestMapping("/cashmovementtypes")
public class CashMovementTypeController  {
	private final CashMovementTypeService cashmovementtypeService;

	public CashMovementTypeController(CashMovementTypeService cashmovementtypeService) {
	   this.cashmovementtypeService = cashmovementtypeService;
	}

	@GetMapping
	public ResponseEntity<List<CashMovementType>> getAllCashMovementTypes() {
	   List<CashMovementType> cashmovementtypes = cashmovementtypeService.getAllCashMovementType();
	   return cashmovementtypes.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(cashmovementtypes);
	}

	@GetMapping("/{id}")
	public ResponseEntity<CashMovementType> getCashMovementTypeById(@PathVariable Long id) {
	   CashMovementType cashmovementtype = cashmovementtypeService.getCashMovementTypeById(id);
	   return ResponseEntity.ok(cashmovementtype);
	}

	@PostMapping
	public ResponseEntity<CashMovementType> createCashMovementType(@RequestBody CashMovementType cashmovementtype) {
	   CashMovementType newCashMovementType = cashmovementtypeService.createCashMovementType(cashmovementtype);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newCashMovementType);
	}

	@PutMapping("/{id}")
	public ResponseEntity<CashMovementType> updateCashMovementType(@PathVariable Long id, @RequestBody CashMovementType cashmovementtype) {
	   CashMovementType updateCashMovementType = cashmovementtypeService.updateCashMovementType(id, cashmovementtype);
	   return ResponseEntity.ok(updateCashMovementType);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteCashMovementTypeById(@PathVariable Long id) {
	   cashmovementtypeService.deleteCashMovementType(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
