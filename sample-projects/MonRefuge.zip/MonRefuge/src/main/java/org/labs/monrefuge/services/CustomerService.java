package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.Customer;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerService  {
	private final CustomerRepository customerRepository;

	@Autowired
	public CustomerService(CustomerRepository customerRepository) {
	   this.customerRepository = customerRepository;
	}

	public List<Customer> getAllCustomer() {
	   return customerRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public Customer getCustomerById(Long id) {
	   Optional<Customer> customer = customerRepository.findById(id);
	   if (customer.isPresent()) {
	     return customer.get();
	   } else {
	     throw new RuntimeException("Customer not found with id : " + id);
	   }
	}

	public Customer createCustomer(Customer customer) {
	   return customerRepository.save(customer);
	}

	public Customer updateCustomer(Long id, Customer customer) {
	   Optional<Customer> existingCustomer = customerRepository.findById(id);
			if (existingCustomer.isPresent()) {
			    customer.setId(id);
	           return customerRepository.save(customer);
	       } else {
	         throw new RuntimeException("Customer not found with id : " + id);
	       }
	}

	public void deleteCustomer(Long id) {
	   customerRepository.deleteById(id);
	}

}
