package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.TypeUser;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.TypeUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class TypeUserService  {
	private final TypeUserRepository typeUserRepository;

	@Autowired
	public TypeUserService(TypeUserRepository typeUserRepository) {
	   this.typeUserRepository = typeUserRepository;
	}

	public List<TypeUser> getAllTypeUser() {
	   return typeUserRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public TypeUser getTypeUserById(Long id) {
	   Optional<TypeUser> typeUser = typeUserRepository.findById(id);
	   if (typeUser.isPresent()) {
	     return typeUser.get();
	   } else {
	     throw new RuntimeException("TypeUser not found with id : " + id);
	   }
	}

	public TypeUser createTypeUser(TypeUser typeUser) {
	   return typeUserRepository.save(typeUser);
	}

	public TypeUser updateTypeUser(Long id, TypeUser typeUser) {
	   Optional<TypeUser> existingTypeUser = typeUserRepository.findById(id);
			if (existingTypeUser.isPresent()) {
			    typeUser.setId(id);
	           return typeUserRepository.save(typeUser);
	       } else {
	         throw new RuntimeException("TypeUser not found with id : " + id);
	       }
	}

	public void deleteTypeUser(Long id) {
	   typeUserRepository.deleteById(id);
	}

}
