package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.Statu;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.StatuService;
import java.util.List;

@RestController
@RequestMapping("/status")
public class StatuController  {
	private final StatuService statuService;

	public StatuController(StatuService statuService) {
	   this.statuService = statuService;
	}

	@GetMapping
	public ResponseEntity<List<Statu>> getAllStatus() {
	   List<Statu> status = statuService.getAllStatu();
	   return status.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(status);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Statu> getStatuById(@PathVariable Long id) {
	   Statu statu = statuService.getStatuById(id);
	   return ResponseEntity.ok(statu);
	}

	@PostMapping
	public ResponseEntity<Statu> createStatu(@RequestBody Statu statu) {
	   Statu newStatu = statuService.createStatu(statu);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newStatu);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Statu> updateStatu(@PathVariable Long id, @RequestBody Statu statu) {
	   Statu updateStatu = statuService.updateStatu(id, statu);
	   return ResponseEntity.ok(updateStatu);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteStatuById(@PathVariable Long id) {
	   statuService.deleteStatu(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
