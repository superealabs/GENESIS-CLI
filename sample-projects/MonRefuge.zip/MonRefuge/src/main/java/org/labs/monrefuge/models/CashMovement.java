package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="cash_movements")
public class CashMovement  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@ManyToOne
	@JoinColumn(name="user_id")
	private User useridUser;

	@ManyToOne
	@JoinColumn(name="daily_cash_summary_id")
	private DailyCashSummary dailycashsummaryidDailyCashSummary;

	@Column(name="movement_date")
	private java.time.LocalDateTime movementDate;

	@ManyToOne
	@JoinColumn(name="category_id")
	private CashMovementsCategorie categoryidCashMovementsCategories;

	@Column(name="amount")
	private Double amount;

	@Column(name="reference")
	private String reference;

	@Column(name="description")
	private String description;

	@Column(name="balance_snapshot")
	private Double balanceSnapshot;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public User getUseridUser() {
	   return useridUser;
	}

	public void setUseridUser(User useridUser) {
	   this.useridUser = useridUser;
	}
	
	public DailyCashSummary getDailycashsummaryidDailyCashSummary() {
	   return dailycashsummaryidDailyCashSummary;
	}

	public void setDailycashsummaryidDailyCashSummary(DailyCashSummary dailycashsummaryidDailyCashSummary) {
	   this.dailycashsummaryidDailyCashSummary = dailycashsummaryidDailyCashSummary;
	}
	
	public java.time.LocalDateTime getMovementDate() {
	   return movementDate;
	}

	public void setMovementDate(java.time.LocalDateTime movementDate) {
	   this.movementDate = movementDate;
	}
	
	public CashMovementsCategorie getCategoryidCashMovementsCategories() {
	   return categoryidCashMovementsCategories;
	}

	public void setCategoryidCashMovementsCategories(CashMovementsCategorie categoryidCashMovementsCategories) {
	   this.categoryidCashMovementsCategories = categoryidCashMovementsCategories;
	}
	
	public Double getAmount() {
	   return amount;
	}

	public void setAmount(Double amount) {
	   this.amount = amount;
	}
	
	public String getReference() {
	   return reference;
	}

	public void setReference(String reference) {
	   this.reference = reference;
	}
	
	public String getDescription() {
	   return description;
	}

	public void setDescription(String description) {
	   this.description = description;
	}
	
	public Double getBalanceSnapshot() {
	   return balanceSnapshot;
	}

	public void setBalanceSnapshot(Double balanceSnapshot) {
	   this.balanceSnapshot = balanceSnapshot;
	}

}
