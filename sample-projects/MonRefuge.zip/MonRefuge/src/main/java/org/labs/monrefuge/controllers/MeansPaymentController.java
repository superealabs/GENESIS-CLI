package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.MeansPayment;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.MeansPaymentService;
import java.util.List;

@RestController
@RequestMapping("/meanspayments")
public class MeansPaymentController  {
	private final MeansPaymentService meanspaymentService;

	public MeansPaymentController(MeansPaymentService meanspaymentService) {
	   this.meanspaymentService = meanspaymentService;
	}

	@GetMapping
	public ResponseEntity<List<MeansPayment>> getAllMeansPayments() {
	   List<MeansPayment> meanspayments = meanspaymentService.getAllMeansPayment();
	   return meanspayments.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(meanspayments);
	}

	@GetMapping("/{id}")
	public ResponseEntity<MeansPayment> getMeansPaymentById(@PathVariable Long id) {
	   MeansPayment meanspayment = meanspaymentService.getMeansPaymentById(id);
	   return ResponseEntity.ok(meanspayment);
	}

	@PostMapping
	public ResponseEntity<MeansPayment> createMeansPayment(@RequestBody MeansPayment meanspayment) {
	   MeansPayment newMeansPayment = meanspaymentService.createMeansPayment(meanspayment);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newMeansPayment);
	}

	@PutMapping("/{id}")
	public ResponseEntity<MeansPayment> updateMeansPayment(@PathVariable Long id, @RequestBody MeansPayment meanspayment) {
	   MeansPayment updateMeansPayment = meanspaymentService.updateMeansPayment(id, meanspayment);
	   return ResponseEntity.ok(updateMeansPayment);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteMeansPaymentById(@PathVariable Long id) {
	   meanspaymentService.deleteMeansPayment(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
