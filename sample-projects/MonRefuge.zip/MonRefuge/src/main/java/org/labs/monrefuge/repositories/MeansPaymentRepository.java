package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.MeansPayment;


public interface MeansPaymentRepository extends JpaRepository<MeansPayment, Long> {
}
