package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="reservation_parameter")
public class ReservationParameter  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@Column(name="number_of_days_before_reservation")
	private Integer numberOfDaysBeforeReservation;

	@Column(name="delay_validation_days")
	private Integer delayValidationDays;

	@Column(name="total_payment_days_before_arrival")
	private Integer totalPaymentDaysBeforeArrival;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public Integer getNumberOfDaysBeforeReservation() {
	   return numberOfDaysBeforeReservation;
	}

	public void setNumberOfDaysBeforeReservation(Integer numberOfDaysBeforeReservation) {
	   this.numberOfDaysBeforeReservation = numberOfDaysBeforeReservation;
	}
	
	public Integer getDelayValidationDays() {
	   return delayValidationDays;
	}

	public void setDelayValidationDays(Integer delayValidationDays) {
	   this.delayValidationDays = delayValidationDays;
	}
	
	public Integer getTotalPaymentDaysBeforeArrival() {
	   return totalPaymentDaysBeforeArrival;
	}

	public void setTotalPaymentDaysBeforeArrival(Integer totalPaymentDaysBeforeArrival) {
	   this.totalPaymentDaysBeforeArrival = totalPaymentDaysBeforeArrival;
	}

}
