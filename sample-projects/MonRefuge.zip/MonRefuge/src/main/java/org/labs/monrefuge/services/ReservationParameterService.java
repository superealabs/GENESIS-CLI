package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.ReservationParameter;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.ReservationParameterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class ReservationParameterService  {
	private final ReservationParameterRepository reservationParameterRepository;

	@Autowired
	public ReservationParameterService(ReservationParameterRepository reservationParameterRepository) {
	   this.reservationParameterRepository = reservationParameterRepository;
	}

	public List<ReservationParameter> getAllReservationParameter() {
	   return reservationParameterRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public ReservationParameter getReservationParameterById(Long id) {
	   Optional<ReservationParameter> reservationParameter = reservationParameterRepository.findById(id);
	   if (reservationParameter.isPresent()) {
	     return reservationParameter.get();
	   } else {
	     throw new RuntimeException("ReservationParameter not found with id : " + id);
	   }
	}

	public ReservationParameter createReservationParameter(ReservationParameter reservationParameter) {
	   return reservationParameterRepository.save(reservationParameter);
	}

	public ReservationParameter updateReservationParameter(Long id, ReservationParameter reservationParameter) {
	   Optional<ReservationParameter> existingReservationParameter = reservationParameterRepository.findById(id);
			if (existingReservationParameter.isPresent()) {
			    reservationParameter.setId(id);
	           return reservationParameterRepository.save(reservationParameter);
	       } else {
	         throw new RuntimeException("ReservationParameter not found with id : " + id);
	       }
	}

	public void deleteReservationParameter(Long id) {
	   reservationParameterRepository.deleteById(id);
	}

}
