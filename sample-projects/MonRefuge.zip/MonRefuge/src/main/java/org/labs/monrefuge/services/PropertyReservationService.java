package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.PropertyReservation;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.PropertyReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyReservationService  {
	private final PropertyReservationRepository propertyReservationRepository;

	@Autowired
	public PropertyReservationService(PropertyReservationRepository propertyReservationRepository) {
	   this.propertyReservationRepository = propertyReservationRepository;
	}

	public List<PropertyReservation> getAllPropertyReservation() {
	   return propertyReservationRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public PropertyReservation getPropertyReservationById(Long id) {
	   Optional<PropertyReservation> propertyReservation = propertyReservationRepository.findById(id);
	   if (propertyReservation.isPresent()) {
	     return propertyReservation.get();
	   } else {
	     throw new RuntimeException("PropertyReservation not found with id : " + id);
	   }
	}

	public PropertyReservation createPropertyReservation(PropertyReservation propertyReservation) {
	   return propertyReservationRepository.save(propertyReservation);
	}

	public PropertyReservation updatePropertyReservation(Long id, PropertyReservation propertyReservation) {
	   Optional<PropertyReservation> existingPropertyReservation = propertyReservationRepository.findById(id);
			if (existingPropertyReservation.isPresent()) {
			    propertyReservation.setId(id);
	           return propertyReservationRepository.save(propertyReservation);
	       } else {
	         throw new RuntimeException("PropertyReservation not found with id : " + id);
	       }
	}

	public void deletePropertyReservation(Long id) {
	   propertyReservationRepository.deleteById(id);
	}

}
