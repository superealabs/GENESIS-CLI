package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.Customer;


public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
