package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.DailyCashSummary;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.DailyCashSummaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class DailyCashSummaryService  {
	private final DailyCashSummaryRepository dailyCashSummaryRepository;

	@Autowired
	public DailyCashSummaryService(DailyCashSummaryRepository dailyCashSummaryRepository) {
	   this.dailyCashSummaryRepository = dailyCashSummaryRepository;
	}

	public List<DailyCashSummary> getAllDailyCashSummary() {
	   return dailyCashSummaryRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public DailyCashSummary getDailyCashSummaryById(Long id) {
	   Optional<DailyCashSummary> dailyCashSummary = dailyCashSummaryRepository.findById(id);
	   if (dailyCashSummary.isPresent()) {
	     return dailyCashSummary.get();
	   } else {
	     throw new RuntimeException("DailyCashSummary not found with id : " + id);
	   }
	}

	public DailyCashSummary createDailyCashSummary(DailyCashSummary dailyCashSummary) {
	   return dailyCashSummaryRepository.save(dailyCashSummary);
	}

	public DailyCashSummary updateDailyCashSummary(Long id, DailyCashSummary dailyCashSummary) {
	   Optional<DailyCashSummary> existingDailyCashSummary = dailyCashSummaryRepository.findById(id);
			if (existingDailyCashSummary.isPresent()) {
			    dailyCashSummary.setId(id);
	           return dailyCashSummaryRepository.save(dailyCashSummary);
	       } else {
	         throw new RuntimeException("DailyCashSummary not found with id : " + id);
	       }
	}

	public void deleteDailyCashSummary(Long id) {
	   dailyCashSummaryRepository.deleteById(id);
	}

}
