package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.User;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.UserService;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController  {
	private final UserService userService;

	public UserController(UserService userService) {
	   this.userService = userService;
	}

	@GetMapping
	public ResponseEntity<List<User>> getAllUsers() {
	   List<User> users = userService.getAllUser();
	   return users.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(users);
	}

	@GetMapping("/{id}")
	public ResponseEntity<User> getUserById(@PathVariable Long id) {
	   User user = userService.getUserById(id);
	   return ResponseEntity.ok(user);
	}

	@PostMapping
	public ResponseEntity<User> createUser(@RequestBody User user) {
	   User newUser = userService.createUser(user);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newUser);
	}

	@PutMapping("/{id}")
	public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) {
	   User updateUser = userService.updateUser(id, user);
	   return ResponseEntity.ok(updateUser);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUserById(@PathVariable Long id) {
	   userService.deleteUser(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
