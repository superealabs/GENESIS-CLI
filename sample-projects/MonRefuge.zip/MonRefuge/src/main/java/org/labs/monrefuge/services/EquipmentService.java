package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.Equipment;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.EquipmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class EquipmentService  {
	private final EquipmentRepository equipmentRepository;

	@Autowired
	public EquipmentService(EquipmentRepository equipmentRepository) {
	   this.equipmentRepository = equipmentRepository;
	}

	public List<Equipment> getAllEquipment() {
	   return equipmentRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public Equipment getEquipmentById(Long id) {
	   Optional<Equipment> equipment = equipmentRepository.findById(id);
	   if (equipment.isPresent()) {
	     return equipment.get();
	   } else {
	     throw new RuntimeException("Equipment not found with id : " + id);
	   }
	}

	public Equipment createEquipment(Equipment equipment) {
	   return equipmentRepository.save(equipment);
	}

	public Equipment updateEquipment(Long id, Equipment equipment) {
	   Optional<Equipment> existingEquipment = equipmentRepository.findById(id);
			if (existingEquipment.isPresent()) {
			    equipment.setId(id);
	           return equipmentRepository.save(equipment);
	       } else {
	         throw new RuntimeException("Equipment not found with id : " + id);
	       }
	}

	public void deleteEquipment(Long id) {
	   equipmentRepository.deleteById(id);
	}

}
