package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.Property;


public interface PropertyRepository extends JpaRepository<Property, Long> {
}
