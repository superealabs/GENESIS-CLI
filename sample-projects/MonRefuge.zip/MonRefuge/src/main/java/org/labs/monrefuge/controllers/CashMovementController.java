package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.CashMovement;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.CashMovementService;
import java.util.List;

@RestController
@RequestMapping("/cashmovements")
public class CashMovementController  {
	private final CashMovementService cashmovementService;

	public CashMovementController(CashMovementService cashmovementService) {
	   this.cashmovementService = cashmovementService;
	}

	@GetMapping
	public ResponseEntity<List<CashMovement>> getAllCashMovements() {
	   List<CashMovement> cashmovements = cashmovementService.getAllCashMovement();
	   return cashmovements.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(cashmovements);
	}

	@GetMapping("/{id}")
	public ResponseEntity<CashMovement> getCashMovementById(@PathVariable Long id) {
	   CashMovement cashmovement = cashmovementService.getCashMovementById(id);
	   return ResponseEntity.ok(cashmovement);
	}

	@PostMapping
	public ResponseEntity<CashMovement> createCashMovement(@RequestBody CashMovement cashmovement) {
	   CashMovement newCashMovement = cashmovementService.createCashMovement(cashmovement);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newCashMovement);
	}

	@PutMapping("/{id}")
	public ResponseEntity<CashMovement> updateCashMovement(@PathVariable Long id, @RequestBody CashMovement cashmovement) {
	   CashMovement updateCashMovement = cashmovementService.updateCashMovement(id, cashmovement);
	   return ResponseEntity.ok(updateCashMovement);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteCashMovementById(@PathVariable Long id) {
	   cashmovementService.deleteCashMovement(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
