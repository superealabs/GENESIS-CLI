package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.CashMovementsCategorie;


public interface CashMovementsCategorieRepository extends JpaRepository<CashMovementsCategorie, Long> {
}
