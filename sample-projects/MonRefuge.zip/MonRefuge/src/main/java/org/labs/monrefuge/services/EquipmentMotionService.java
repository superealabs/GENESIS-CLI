package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.EquipmentMotion;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.EquipmentMotionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class EquipmentMotionService  {
	private final EquipmentMotionRepository equipmentMotionRepository;

	@Autowired
	public EquipmentMotionService(EquipmentMotionRepository equipmentMotionRepository) {
	   this.equipmentMotionRepository = equipmentMotionRepository;
	}

	public List<EquipmentMotion> getAllEquipmentMotion() {
	   return equipmentMotionRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public EquipmentMotion getEquipmentMotionById(Long id) {
	   Optional<EquipmentMotion> equipmentMotion = equipmentMotionRepository.findById(id);
	   if (equipmentMotion.isPresent()) {
	     return equipmentMotion.get();
	   } else {
	     throw new RuntimeException("EquipmentMotion not found with id : " + id);
	   }
	}

	public EquipmentMotion createEquipmentMotion(EquipmentMotion equipmentMotion) {
	   return equipmentMotionRepository.save(equipmentMotion);
	}

	public EquipmentMotion updateEquipmentMotion(Long id, EquipmentMotion equipmentMotion) {
	   Optional<EquipmentMotion> existingEquipmentMotion = equipmentMotionRepository.findById(id);
			if (existingEquipmentMotion.isPresent()) {
			    equipmentMotion.setId(id);
	           return equipmentMotionRepository.save(equipmentMotion);
	       } else {
	         throw new RuntimeException("EquipmentMotion not found with id : " + id);
	       }
	}

	public void deleteEquipmentMotion(Long id) {
	   equipmentMotionRepository.deleteById(id);
	}

}
