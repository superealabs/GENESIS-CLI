package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.Invoice;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.InvoiceService;
import java.util.List;

@RestController
@RequestMapping("/invoices")
public class InvoiceController  {
	private final InvoiceService invoiceService;

	public InvoiceController(InvoiceService invoiceService) {
	   this.invoiceService = invoiceService;
	}

	@GetMapping
	public ResponseEntity<List<Invoice>> getAllInvoices() {
	   List<Invoice> invoices = invoiceService.getAllInvoice();
	   return invoices.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(invoices);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Invoice> getInvoiceById(@PathVariable Long id) {
	   Invoice invoice = invoiceService.getInvoiceById(id);
	   return ResponseEntity.ok(invoice);
	}

	@PostMapping
	public ResponseEntity<Invoice> createInvoice(@RequestBody Invoice invoice) {
	   Invoice newInvoice = invoiceService.createInvoice(invoice);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newInvoice);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Invoice> updateInvoice(@PathVariable Long id, @RequestBody Invoice invoice) {
	   Invoice updateInvoice = invoiceService.updateInvoice(id, invoice);
	   return ResponseEntity.ok(updateInvoice);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteInvoiceById(@PathVariable Long id) {
	   invoiceService.deleteInvoice(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
