package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.PropertyCategory;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.PropertyCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyCategoryService  {
	private final PropertyCategoryRepository propertyCategoryRepository;

	@Autowired
	public PropertyCategoryService(PropertyCategoryRepository propertyCategoryRepository) {
	   this.propertyCategoryRepository = propertyCategoryRepository;
	}

	public List<PropertyCategory> getAllPropertyCategory() {
	   return propertyCategoryRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public PropertyCategory getPropertyCategoryById(Long id) {
	   Optional<PropertyCategory> propertyCategory = propertyCategoryRepository.findById(id);
	   if (propertyCategory.isPresent()) {
	     return propertyCategory.get();
	   } else {
	     throw new RuntimeException("PropertyCategory not found with id : " + id);
	   }
	}

	public PropertyCategory createPropertyCategory(PropertyCategory propertyCategory) {
	   return propertyCategoryRepository.save(propertyCategory);
	}

	public PropertyCategory updatePropertyCategory(Long id, PropertyCategory propertyCategory) {
	   Optional<PropertyCategory> existingPropertyCategory = propertyCategoryRepository.findById(id);
			if (existingPropertyCategory.isPresent()) {
			    propertyCategory.setId(id);
	           return propertyCategoryRepository.save(propertyCategory);
	       } else {
	         throw new RuntimeException("PropertyCategory not found with id : " + id);
	       }
	}

	public void deletePropertyCategory(Long id) {
	   propertyCategoryRepository.deleteById(id);
	}

}
