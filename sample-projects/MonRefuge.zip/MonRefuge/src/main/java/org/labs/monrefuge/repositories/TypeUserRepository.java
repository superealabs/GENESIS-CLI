package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.TypeUser;


public interface TypeUserRepository extends JpaRepository<TypeUser, Long> {
}
