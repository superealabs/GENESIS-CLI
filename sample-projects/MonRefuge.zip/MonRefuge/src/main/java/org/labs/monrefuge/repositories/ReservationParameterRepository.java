package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.ReservationParameter;


public interface ReservationParameterRepository extends JpaRepository<ReservationParameter, Long> {
}
