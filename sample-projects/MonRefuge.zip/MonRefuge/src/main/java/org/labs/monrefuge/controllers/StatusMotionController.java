package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.StatusMotion;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.StatusMotionService;
import java.util.List;

@RestController
@RequestMapping("/statusmotions")
public class StatusMotionController  {
	private final StatusMotionService statusmotionService;

	public StatusMotionController(StatusMotionService statusmotionService) {
	   this.statusmotionService = statusmotionService;
	}

	@GetMapping
	public ResponseEntity<List<StatusMotion>> getAllStatusMotions() {
	   List<StatusMotion> statusmotions = statusmotionService.getAllStatusMotion();
	   return statusmotions.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(statusmotions);
	}

	@GetMapping("/{id}")
	public ResponseEntity<StatusMotion> getStatusMotionById(@PathVariable Long id) {
	   StatusMotion statusmotion = statusmotionService.getStatusMotionById(id);
	   return ResponseEntity.ok(statusmotion);
	}

	@PostMapping
	public ResponseEntity<StatusMotion> createStatusMotion(@RequestBody StatusMotion statusmotion) {
	   StatusMotion newStatusMotion = statusmotionService.createStatusMotion(statusmotion);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newStatusMotion);
	}

	@PutMapping("/{id}")
	public ResponseEntity<StatusMotion> updateStatusMotion(@PathVariable Long id, @RequestBody StatusMotion statusmotion) {
	   StatusMotion updateStatusMotion = statusmotionService.updateStatusMotion(id, statusmotion);
	   return ResponseEntity.ok(updateStatusMotion);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteStatusMotionById(@PathVariable Long id) {
	   statusmotionService.deleteStatusMotion(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
