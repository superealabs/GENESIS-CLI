package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.EquipmentMotion;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.EquipmentMotionService;
import java.util.List;

@RestController
@RequestMapping("/equipmentmotions")
public class EquipmentMotionController  {
	private final EquipmentMotionService equipmentmotionService;

	public EquipmentMotionController(EquipmentMotionService equipmentmotionService) {
	   this.equipmentmotionService = equipmentmotionService;
	}

	@GetMapping
	public ResponseEntity<List<EquipmentMotion>> getAllEquipmentMotions() {
	   List<EquipmentMotion> equipmentmotions = equipmentmotionService.getAllEquipmentMotion();
	   return equipmentmotions.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(equipmentmotions);
	}

	@GetMapping("/{id}")
	public ResponseEntity<EquipmentMotion> getEquipmentMotionById(@PathVariable Long id) {
	   EquipmentMotion equipmentmotion = equipmentmotionService.getEquipmentMotionById(id);
	   return ResponseEntity.ok(equipmentmotion);
	}

	@PostMapping
	public ResponseEntity<EquipmentMotion> createEquipmentMotion(@RequestBody EquipmentMotion equipmentmotion) {
	   EquipmentMotion newEquipmentMotion = equipmentmotionService.createEquipmentMotion(equipmentmotion);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newEquipmentMotion);
	}

	@PutMapping("/{id}")
	public ResponseEntity<EquipmentMotion> updateEquipmentMotion(@PathVariable Long id, @RequestBody EquipmentMotion equipmentmotion) {
	   EquipmentMotion updateEquipmentMotion = equipmentmotionService.updateEquipmentMotion(id, equipmentmotion);
	   return ResponseEntity.ok(updateEquipmentMotion);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteEquipmentMotionById(@PathVariable Long id) {
	   equipmentmotionService.deleteEquipmentMotion(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
