package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.EquipmentCategory;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.EquipmentCategoryService;
import java.util.List;

@RestController
@RequestMapping("/equipmentcategorys")
public class EquipmentCategoryController  {
	private final EquipmentCategoryService equipmentcategoryService;

	public EquipmentCategoryController(EquipmentCategoryService equipmentcategoryService) {
	   this.equipmentcategoryService = equipmentcategoryService;
	}

	@GetMapping
	public ResponseEntity<List<EquipmentCategory>> getAllEquipmentCategorys() {
	   List<EquipmentCategory> equipmentcategorys = equipmentcategoryService.getAllEquipmentCategory();
	   return equipmentcategorys.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(equipmentcategorys);
	}

	@GetMapping("/{id}")
	public ResponseEntity<EquipmentCategory> getEquipmentCategoryById(@PathVariable Long id) {
	   EquipmentCategory equipmentcategory = equipmentcategoryService.getEquipmentCategoryById(id);
	   return ResponseEntity.ok(equipmentcategory);
	}

	@PostMapping
	public ResponseEntity<EquipmentCategory> createEquipmentCategory(@RequestBody EquipmentCategory equipmentcategory) {
	   EquipmentCategory newEquipmentCategory = equipmentcategoryService.createEquipmentCategory(equipmentcategory);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newEquipmentCategory);
	}

	@PutMapping("/{id}")
	public ResponseEntity<EquipmentCategory> updateEquipmentCategory(@PathVariable Long id, @RequestBody EquipmentCategory equipmentcategory) {
	   EquipmentCategory updateEquipmentCategory = equipmentcategoryService.updateEquipmentCategory(id, equipmentcategory);
	   return ResponseEntity.ok(updateEquipmentCategory);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteEquipmentCategoryById(@PathVariable Long id) {
	   equipmentcategoryService.deleteEquipmentCategory(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
