package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.EquipmentRental;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.EquipmentRentalService;
import java.util.List;

@RestController
@RequestMapping("/equipmentrentals")
public class EquipmentRentalController  {
	private final EquipmentRentalService equipmentrentalService;

	public EquipmentRentalController(EquipmentRentalService equipmentrentalService) {
	   this.equipmentrentalService = equipmentrentalService;
	}

	@GetMapping
	public ResponseEntity<List<EquipmentRental>> getAllEquipmentRentals() {
	   List<EquipmentRental> equipmentrentals = equipmentrentalService.getAllEquipmentRental();
	   return equipmentrentals.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(equipmentrentals);
	}

	@GetMapping("/{id}")
	public ResponseEntity<EquipmentRental> getEquipmentRentalById(@PathVariable Long id) {
	   EquipmentRental equipmentrental = equipmentrentalService.getEquipmentRentalById(id);
	   return ResponseEntity.ok(equipmentrental);
	}

	@PostMapping
	public ResponseEntity<EquipmentRental> createEquipmentRental(@RequestBody EquipmentRental equipmentrental) {
	   EquipmentRental newEquipmentRental = equipmentrentalService.createEquipmentRental(equipmentrental);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newEquipmentRental);
	}

	@PutMapping("/{id}")
	public ResponseEntity<EquipmentRental> updateEquipmentRental(@PathVariable Long id, @RequestBody EquipmentRental equipmentrental) {
	   EquipmentRental updateEquipmentRental = equipmentrentalService.updateEquipmentRental(id, equipmentrental);
	   return ResponseEntity.ok(updateEquipmentRental);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteEquipmentRentalById(@PathVariable Long id) {
	   equipmentrentalService.deleteEquipmentRental(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
