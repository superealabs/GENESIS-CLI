package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.CashMovementsTypeCategorie;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.CashMovementsTypeCategorieService;
import java.util.List;

@RestController
@RequestMapping("/cashmovementstypecategories")
public class CashMovementsTypeCategorieController  {
	private final CashMovementsTypeCategorieService cashmovementstypecategorieService;

	public CashMovementsTypeCategorieController(CashMovementsTypeCategorieService cashmovementstypecategorieService) {
	   this.cashmovementstypecategorieService = cashmovementstypecategorieService;
	}

	@GetMapping
	public ResponseEntity<List<CashMovementsTypeCategorie>> getAllCashMovementsTypeCategories() {
	   List<CashMovementsTypeCategorie> cashmovementstypecategories = cashmovementstypecategorieService.getAllCashMovementsTypeCategorie();
	   return cashmovementstypecategories.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(cashmovementstypecategories);
	}

	@GetMapping("/{id}")
	public ResponseEntity<CashMovementsTypeCategorie> getCashMovementsTypeCategorieById(@PathVariable Long id) {
	   CashMovementsTypeCategorie cashmovementstypecategorie = cashmovementstypecategorieService.getCashMovementsTypeCategorieById(id);
	   return ResponseEntity.ok(cashmovementstypecategorie);
	}

	@PostMapping
	public ResponseEntity<CashMovementsTypeCategorie> createCashMovementsTypeCategorie(@RequestBody CashMovementsTypeCategorie cashmovementstypecategorie) {
	   CashMovementsTypeCategorie newCashMovementsTypeCategorie = cashmovementstypecategorieService.createCashMovementsTypeCategorie(cashmovementstypecategorie);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newCashMovementsTypeCategorie);
	}

	@PutMapping("/{id}")
	public ResponseEntity<CashMovementsTypeCategorie> updateCashMovementsTypeCategorie(@PathVariable Long id, @RequestBody CashMovementsTypeCategorie cashmovementstypecategorie) {
	   CashMovementsTypeCategorie updateCashMovementsTypeCategorie = cashmovementstypecategorieService.updateCashMovementsTypeCategorie(id, cashmovementstypecategorie);
	   return ResponseEntity.ok(updateCashMovementsTypeCategorie);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteCashMovementsTypeCategorieById(@PathVariable Long id) {
	   cashmovementstypecategorieService.deleteCashMovementsTypeCategorie(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
