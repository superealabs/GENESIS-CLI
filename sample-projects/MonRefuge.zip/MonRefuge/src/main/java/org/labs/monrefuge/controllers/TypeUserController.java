package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.TypeUser;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.TypeUserService;
import java.util.List;

@RestController
@RequestMapping("/typeusers")
public class TypeUserController  {
	private final TypeUserService typeuserService;

	public TypeUserController(TypeUserService typeuserService) {
	   this.typeuserService = typeuserService;
	}

	@GetMapping
	public ResponseEntity<List<TypeUser>> getAllTypeUsers() {
	   List<TypeUser> typeusers = typeuserService.getAllTypeUser();
	   return typeusers.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(typeusers);
	}

	@GetMapping("/{id}")
	public ResponseEntity<TypeUser> getTypeUserById(@PathVariable Long id) {
	   TypeUser typeuser = typeuserService.getTypeUserById(id);
	   return ResponseEntity.ok(typeuser);
	}

	@PostMapping
	public ResponseEntity<TypeUser> createTypeUser(@RequestBody TypeUser typeuser) {
	   TypeUser newTypeUser = typeuserService.createTypeUser(typeuser);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newTypeUser);
	}

	@PutMapping("/{id}")
	public ResponseEntity<TypeUser> updateTypeUser(@PathVariable Long id, @RequestBody TypeUser typeuser) {
	   TypeUser updateTypeUser = typeuserService.updateTypeUser(id, typeuser);
	   return ResponseEntity.ok(updateTypeUser);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteTypeUserById(@PathVariable Long id) {
	   typeuserService.deleteTypeUser(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
