package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.Invoice;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class InvoiceService  {
	private final InvoiceRepository invoiceRepository;

	@Autowired
	public InvoiceService(InvoiceRepository invoiceRepository) {
	   this.invoiceRepository = invoiceRepository;
	}

	public List<Invoice> getAllInvoice() {
	   return invoiceRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public Invoice getInvoiceById(Long id) {
	   Optional<Invoice> invoice = invoiceRepository.findById(id);
	   if (invoice.isPresent()) {
	     return invoice.get();
	   } else {
	     throw new RuntimeException("Invoice not found with id : " + id);
	   }
	}

	public Invoice createInvoice(Invoice invoice) {
	   return invoiceRepository.save(invoice);
	}

	public Invoice updateInvoice(Long id, Invoice invoice) {
	   Optional<Invoice> existingInvoice = invoiceRepository.findById(id);
			if (existingInvoice.isPresent()) {
			    invoice.setId(id);
	           return invoiceRepository.save(invoice);
	       } else {
	         throw new RuntimeException("Invoice not found with id : " + id);
	       }
	}

	public void deleteInvoice(Long id) {
	   invoiceRepository.deleteById(id);
	}

}
