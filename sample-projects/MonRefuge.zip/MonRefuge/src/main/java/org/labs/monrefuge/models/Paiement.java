package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="paiements")
public class Paiement  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@ManyToOne
	@JoinColumn(name="user_id")
	private User useridUser;

	@ManyToOne
	@JoinColumn(name="invoice_id")
	private Invoice invoiceidInvoices;

	@ManyToOne
	@JoinColumn(name="means_payments_id")
	private MeansPayment meanspaymentsidMeansPayments;

	@Column(name="price_pay")
	private Double pricePay;

	@Column(name="reference")
	private String reference;

	@Column(name="date_time_payment")
	private java.time.LocalDateTime dateTimePayment;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public User getUseridUser() {
	   return useridUser;
	}

	public void setUseridUser(User useridUser) {
	   this.useridUser = useridUser;
	}
	
	public Invoice getInvoiceidInvoices() {
	   return invoiceidInvoices;
	}

	public void setInvoiceidInvoices(Invoice invoiceidInvoices) {
	   this.invoiceidInvoices = invoiceidInvoices;
	}
	
	public MeansPayment getMeanspaymentsidMeansPayments() {
	   return meanspaymentsidMeansPayments;
	}

	public void setMeanspaymentsidMeansPayments(MeansPayment meanspaymentsidMeansPayments) {
	   this.meanspaymentsidMeansPayments = meanspaymentsidMeansPayments;
	}
	
	public Double getPricePay() {
	   return pricePay;
	}

	public void setPricePay(Double pricePay) {
	   this.pricePay = pricePay;
	}
	
	public String getReference() {
	   return reference;
	}

	public void setReference(String reference) {
	   this.reference = reference;
	}
	
	public java.time.LocalDateTime getDateTimePayment() {
	   return dateTimePayment;
	}

	public void setDateTimePayment(java.time.LocalDateTime dateTimePayment) {
	   this.dateTimePayment = dateTimePayment;
	}

}
