package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.User;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class UserService  {
	private final UserRepository userRepository;

	@Autowired
	public UserService(UserRepository userRepository) {
	   this.userRepository = userRepository;
	}

	public List<User> getAllUser() {
	   return userRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public User getUserById(Long id) {
	   Optional<User> user = userRepository.findById(id);
	   if (user.isPresent()) {
	     return user.get();
	   } else {
	     throw new RuntimeException("User not found with id : " + id);
	   }
	}

	public User createUser(User user) {
	   return userRepository.save(user);
	}

	public User updateUser(Long id, User user) {
	   Optional<User> existingUser = userRepository.findById(id);
			if (existingUser.isPresent()) {
			    user.setId(id);
	           return userRepository.save(user);
	       } else {
	         throw new RuntimeException("User not found with id : " + id);
	       }
	}

	public void deleteUser(Long id) {
	   userRepository.deleteById(id);
	}

}
