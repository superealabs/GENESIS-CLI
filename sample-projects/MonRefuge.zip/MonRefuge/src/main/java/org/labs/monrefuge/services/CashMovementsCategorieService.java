package org.labs.monrefuge.services;

import org.springframework.data.domain.Sort;
import org.labs.monrefuge.models.CashMovementsCategorie;
import org.springframework.stereotype.Service;
import org.labs.monrefuge.repositories.CashMovementsCategorieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;

@Service
public class CashMovementsCategorieService  {
	private final CashMovementsCategorieRepository cashMovementsCategorieRepository;

	@Autowired
	public CashMovementsCategorieService(CashMovementsCategorieRepository cashMovementsCategorieRepository) {
	   this.cashMovementsCategorieRepository = cashMovementsCategorieRepository;
	}

	public List<CashMovementsCategorie> getAllCashMovementsCategorie() {
	   return cashMovementsCategorieRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
	}

	public CashMovementsCategorie getCashMovementsCategorieById(Long id) {
	   Optional<CashMovementsCategorie> cashMovementsCategorie = cashMovementsCategorieRepository.findById(id);
	   if (cashMovementsCategorie.isPresent()) {
	     return cashMovementsCategorie.get();
	   } else {
	     throw new RuntimeException("CashMovementsCategorie not found with id : " + id);
	   }
	}

	public CashMovementsCategorie createCashMovementsCategorie(CashMovementsCategorie cashMovementsCategorie) {
	   return cashMovementsCategorieRepository.save(cashMovementsCategorie);
	}

	public CashMovementsCategorie updateCashMovementsCategorie(Long id, CashMovementsCategorie cashMovementsCategorie) {
	   Optional<CashMovementsCategorie> existingCashMovementsCategorie = cashMovementsCategorieRepository.findById(id);
			if (existingCashMovementsCategorie.isPresent()) {
			    cashMovementsCategorie.setId(id);
	           return cashMovementsCategorieRepository.save(cashMovementsCategorie);
	       } else {
	         throw new RuntimeException("CashMovementsCategorie not found with id : " + id);
	       }
	}

	public void deleteCashMovementsCategorie(Long id) {
	   cashMovementsCategorieRepository.deleteById(id);
	}

}
