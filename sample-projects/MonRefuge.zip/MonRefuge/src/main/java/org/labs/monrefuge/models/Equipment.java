package org.labs.monrefuge.models;

import jakarta.persistence.*;

@Entity
@Table(name="equipment")
public class Equipment  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;

	@Column(name="name")
	private String name;

	@Column(name="description")
	private String description;

	@ManyToOne
	@JoinColumn(name="equipment_category_id")
	private EquipmentCategory equipmentcategoryidEquipmentCategory;
	

	public Long getId() {
	   return id;
	}

	public void setId(Long id) {
	   this.id = id;
	}
	
	public String getName() {
	   return name;
	}

	public void setName(String name) {
	   this.name = name;
	}
	
	public String getDescription() {
	   return description;
	}

	public void setDescription(String description) {
	   this.description = description;
	}
	
	public EquipmentCategory getEquipmentcategoryidEquipmentCategory() {
	   return equipmentcategoryidEquipmentCategory;
	}

	public void setEquipmentcategoryidEquipmentCategory(EquipmentCategory equipmentcategoryidEquipmentCategory) {
	   this.equipmentcategoryidEquipmentCategory = equipmentcategoryidEquipmentCategory;
	}

}
