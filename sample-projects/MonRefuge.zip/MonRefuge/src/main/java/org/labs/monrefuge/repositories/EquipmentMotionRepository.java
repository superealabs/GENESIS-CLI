package org.labs.monrefuge.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.labs.monrefuge.models.EquipmentMotion;


public interface EquipmentMotionRepository extends JpaRepository<EquipmentMotion, Long> {
}
