package org.labs.monrefuge.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.labs.monrefuge.models.Property;
import org.springframework.web.bind.annotation.*;
import org.labs.monrefuge.services.PropertyService;
import java.util.List;

@RestController
@RequestMapping("/propertys")
public class PropertyController  {
	private final PropertyService propertyService;

	public PropertyController(PropertyService propertyService) {
	   this.propertyService = propertyService;
	}

	@GetMapping
	public ResponseEntity<List<Property>> getAllPropertys() {
	   List<Property> propertys = propertyService.getAllProperty();
	   return propertys.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(propertys);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Property> getPropertyById(@PathVariable Long id) {
	   Property property = propertyService.getPropertyById(id);
	   return ResponseEntity.ok(property);
	}

	@PostMapping
	public ResponseEntity<Property> createProperty(@RequestBody Property property) {
	   Property newProperty = propertyService.createProperty(property);
	   return ResponseEntity.status(HttpStatus.CREATED).body(newProperty);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Property> updateProperty(@PathVariable Long id, @RequestBody Property property) {
	   Property updateProperty = propertyService.updateProperty(id, property);
	   return ResponseEntity.ok(updateProperty);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletePropertyById(@PathVariable Long id) {
	   propertyService.deleteProperty(id);
	   return ResponseEntity.noContent().build();
	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleRuntimeException(RuntimeException ex) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	}

}
