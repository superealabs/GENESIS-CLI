package org.labs.monrefuge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonRefugeApplicationTests {

	@Test
	void contextLoads() {
	}

}
